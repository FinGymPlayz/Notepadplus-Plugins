import handler.main as npp
import handler.log as log
import handler.config as config

js = """
{
    "title": "ENTER CUSTOM TITLE HERE"
}
"""
config.create("custom_title",js)

title = config.get_config("title")
npp.set_title(title)
npp.set_custom_gui("Edit Config.yml",lambda: config.launch_config())



npp.main()