import handler.main as npp
import handler.log as log
import handler.config as config
from tkinter import *

#!Creating our config varible
js = """
{
    "say_hi": true
}
"""
#!Defining our config
config.create("say_hi", js)

say_hi = config.get_config("say_hi")
if say_hi == True:
    npp.alert("Hi!")

#!Adding a GUI to edit our config
npp.set_custom_gui("Config",lambda: config.launch_config())

npp.main()