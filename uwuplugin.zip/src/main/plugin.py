import handler.main as npp
import handler.log as log
import handler.config as config

uwu = "uwu"
for i in range(1000):
    uwu = uwu+"uwu"
npp.insert(uwu)





npp.main()