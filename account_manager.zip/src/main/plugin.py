import handler.main as npp
import handler.log as log
import handler.config as config
from tkinter import *

path = "C:\\npnp_account"

def reset_pass():
    w = Tk()
    def set_pass():
        password = raw_password.get()
        with open(f"{path}\\password.txt", 'w')as f:
            f.write(password)
        w.destroy()
        npp.alert("Password Rest!")
    
    Label(w, text="New Password").pack()
    raw_password = Entry(w)
    raw_password.pack()
    Button(w, text="Set Password", command=set_pass).pack()
    
    w.mainloop()

npp.menu.create_menu(
    "AccM",
    "Account Manager",
)
npp.menu.add_menu_item(
    "AccM",
    "Reset Password",
    reset_pass
)




npp.main()