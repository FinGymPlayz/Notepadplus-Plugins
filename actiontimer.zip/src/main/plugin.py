import handler.main as npp
import handler.log as log
import handler.config as config
from tkinter import *
import threading
import time as t
import os

def open_window():
    w = Tk()
    def run():
        def run_thread():
            w.destroy()
            dat = config.data.get("log")
            config.data.set("log",dat + ","+action)
            npp.alert("Starting Timer for "+time+" seconds!")
            t.sleep(int(time))
            os.system(action)
            
        time = time_raw.get()
        action = action_raw.get()
        thread = threading.Thread(target=run_thread)
        thread.start()
    
    Label(w,text="Time (seconds)").pack()
    time_raw = Entry(w)
    action_raw = Entry(w)
    time_raw.pack()
    Label(w,text="terminal command").pack()
    action_raw.pack()
    Button(w,text="Run",comman=run).pack()
    
    w.mainloop()

npp.set_custom_gui("Action Timer",open_window)


npp.main()