import handler.main as npp
import handler.log as log
import handler.config as config


npp.tab.website("How to set up")
npp.insert("This plugin is not needed after setup!!!\n\n")





npp.main()