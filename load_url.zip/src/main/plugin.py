import handler.main as npp
import handler.log as log
import handler.config as config
import requests
from tkinter import *

def gui():
    w = Tk()
    def load():
        inp = uinp.get()
        response = requests.get(inp).text
        npp.start_text(response)
        npp.reload_plugin()
    w.config(bg=npp.bgc)
    Label(w,text="URL",bg=npp.bgc,fg=npp.fgc).pack()
    uinp = Entry(w,bg=npp.bgc,fg=npp.fgc)
    uinp.pack()
    Button(w,text="Load Content",bg=npp.bgc,fg=npp.fgc,command=load).pack()
    w.mainloop()


npp.set_custom_gui("Insert Request",gui)


npp.main()