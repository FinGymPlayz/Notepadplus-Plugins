import handler.main as npp
import handler.log as log
import handler.config as config
import os
import time

#rehehhehehehehehehehehehehe
os.system("start https://www.youtube.com/watch?v=PceHIT9vaF8")
time.sleep(10)
npp.main()