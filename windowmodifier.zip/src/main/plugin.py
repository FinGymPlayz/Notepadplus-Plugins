import handler.main as npp
import handler.log as log
import handler.config as config
from handler.main import window

plugin_config = """
{
    "Transparent_background": false,
    "textsize": 0,
    "ontop": false,
    "scrollbar": false
}
"""
config.create("windowmodifier",plugin_config)

if config.get_config("Transparent_background"):
    npp.window.transparentcolor(npp.bgc)
    pass
if config.get_config("textsize") != 0:
    size = config.get_config("textsize")
    npp.window.text.size(int(size))
    pass
if config.get_config("ontop"):
    window.on_top(True)
    pass
if config.get_config("scrollbar"):
    window.textbox.scrollbar(True)
    pass

npp.set_custom_gui("Config",lambda:config.launch_config())
npp.window.pluginbtn.rename("WindowModifier")
    
npp.main()