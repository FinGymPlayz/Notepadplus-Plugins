import handler.main as npp
import handler.log as log
import handler.config as config
from tkinter import *

log.info("Notepad plus has loaded!")

npp.check_version(1.7)

def GUI():

    dat = npp.FetchData()
    bgc = dat.get_theme("bg")
    fgc = dat.get_theme("fg")
    scc = dat.get_theme("secondary")
    rcc = dat.get_theme("rcmenu")


    log.info("Started GUI")
    w = Tk()

    def fga():
        fg = fgraw.get()
        npp.color_foreground(fg)
    def bga():
        bg = bgraw.get()
        npp.color_background(bg)
    def sca():
        sc = scraw.get()
        npp.color_secondary(sc)
    def rca():
        rc = rcraw.get()
        npp.color_rcmenu(rc)

    w.geometry("450x350")
    w.title("Easy Theme - FinGymPlayz")

    Label(w,text="Foreground (Text Color)").pack()
    fgraw = Entry(w)
    fgraw.insert(END, fgc)
    fgraw.pack()
    Button(w,text="Apply Foreground", command=fga).pack()

    Label(w,text="Background Color").pack()
    bgraw = Entry(w)
    bgraw.insert(END, bgc)
    bgraw.pack()
    Button(w,text="Apply Background", command=bga).pack()

    Label(w,text="Secondary Color (Bottom bar)").pack()
    scraw = Entry(w)
    scraw.insert(END, scc)
    scraw.pack()
    Button(w,text="Apply Secondary Color", command=sca).pack()

    Label(w,text="Right Click menu color (Color of the text when you right click)").pack()
    rcraw = Entry(w)
    rcraw.insert(END, rcc)
    rcraw.pack()
    Button(w,text="Apply Right Click Colors", command=rca).pack()
    Label(w,text="TO APPLY CHANGES PLEASE RIGHTCLICK ON NOTEPADPLUS\nAND CLICK RELOAD").pack(pady=20)

    w.mainloop()


def HTU():
    a = Tk()

    dat = npp.FetchData()
    bgc = dat.get_theme("bg")
    fgc = dat.get_theme("fg")

    a.config(bg=bgc)

    a.title("How To Use")
    Label(a,fg=fgc,bg=bgc,text="1. Open the Custom Themes Menu\n\n2. Change the colors, like change foreground to\nred.\n\n3. Click apply\n\n4. Close the Theme menu\n\n5. Right click on NotepadPlus\n\n6. And click reload\n\n\n\nHow to set back to default\n\n1. On NotepadPlus click settings\n\n2. Then click themes\n\n3. Then click default").pack()

    a.mainloop()


npp.set_custom_gui("Custom Theme", GUI)
npp.set_custom_action("How to use", HTU)


npp.main()




