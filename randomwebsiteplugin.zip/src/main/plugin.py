import os
import handler.main as npp
import handler.log as log
import handler.config as config
import random

plugin_config = """
{
    "websites": ["https://google.com","https://youtube.com"]
}
"""
config.create("randomwebsiteplugin",plugin_config)

websites = config.get_config("websites")

def launch_random_website():
    random_website = random.choice(websites)
    os.system(f"start {random_website}")

npp.set_custom_gui("Launch Random Website",launch_random_website)
npp.set_custom_action("Edit Websites >> config",lambda: config.launch_config())



npp.main()