import handler.main as npp
import handler.log as log
import handler.config as config
import random
import threading
import time

insults = [
    "You're as useful as a screen door on a submarine.",
    "If stupidity were a talent, you'd be a prodigy.",
    "If ignorance is bliss, you must be the happiest person on Earth.",
    "You're the reason they invented the phrase 'facepalm'.",
    "If your brain was a muscle, you'd be a complete weakling.",
    "It's a shame you're a living example of natural selection gone wrong.",
    "I'd enlighten you, but I doubt you'd comprehend.",
    "You have an entire lifetime to be unpleasant. Why not take today off?",
    "You're so dense, light bends around you.",
    "Your family tree must be a bonsai, because everyone in it is a tiny branch.",
    "If I wanted to lower my IQ, I'd engage in a conversation with you.",
    "You're so unattractive that even burglars wouldn't steal from you.",
    "I'm sorry, did I give you the impression that I value your opinion?",
    "If I had a penny for every ounce of intelligence you possess, I'd have one cent.",
    "If you were any more inbred, you'd be a sandwich.",
    "Are you always this clueless, or are you making a special effort today?",
    "I'd love to see things from your perspective, but I can't seem to get my head that far up my backside.",
    "If you're going to be two-faced, at least make one of them pretty.",
    "Does your rear end feel envious of the amount of garbage that comes out of your mouth?",
    "You're not attractive enough to compensate for your lack of intellect.",
    "I'd refer to you as a tool, but that would imply you have some usefulness.",
    "You're the reason lifeguards exist for the gene pool.",
    "If laughter is the best medicine, your face must be curing the world.",
    "I was going to give you a nasty look, but I see you already have one.",
    "You're so unattractive that you scare the crap out of toilets.",
    "You bring joy to everyone when you leave the room.",
    "I would prioritize charging my phone over your life support.",
    "You're like a never-ending Monday, a perpetual annoyance.",
    "You're so corpulent that you could sell shade.",
    "You're so unattractive that when you were born, the doctor slapped your parents.",
    "You must have been born on a highway, because that's where most accidents happen.",
    "If I wanted to listen to a fool, I'd fart.",
    "It's a shame two heads don't equate to twice the intelligence.",
    "I'm envious of people who haven't had the displeasure of meeting you.",
    "You're the reason shampoo bottles have instructions.",
    "If your face matched your attitude, you'd be considered attractive.",
    "I'd metaphorically slap you, but that would be animal abuse.",
    "I'm trying my utmost to understand your perspective, but my head isn't built to fit up my backside.",
    "You're as worthless as a one-cent coin.",
    "You're so unattractive that you could make onions cry.",
    "If I wanted to end my life, I'd ascend your ego and descend to your IQ level.",
    "You're so full of nonsense that toilets are envious.",
    "Some people bring happiness wherever they go, and you bring happiness whenever you leave.",
    "I feel sorry for people who haven't had the misfortune of meeting you.",
    "If your brain was chocolate, it wouldn't be enough to fill an M&M.",
    "Your face could turn any conversation into an argument.",
    "I'd suggest you go to hell, but I don't want to see you every day at work.",
    "You're the human equivalent of period cramps.",
    "I'd explain it to you, but I don't have enough time or crayons.",
    "You're so unattractive that you could be considered a modern art masterpiece.",
    "I'm not saying I dislike you, but I would unplug your life support to charge my phone.",
    "You're the reason why God created the middle finger.",
    "If brains were dynamite, you wouldn't have enough to blow your nose.",
    "You're so dense, light bends around you."
]

js = """
{
    "Enabled": true,
    "roast_randomly_s": 60
}
"""
config.create("roastme",js)


def run():
    ran_time = random.randint(0,int(config.get_config("roast_randomly_s")))
    def insult_me():
        ran_insult = random.choice(insults)
        npp.tts(ran_insult)
        run()
    time.sleep(ran_time)
    insult_me()

if config.get_config("Enabled"):
    thread = threading.Thread(target=run)
    thread.start()

npp.set_custom_gui("Edit Config.yml",lambda: config.launch_config())

npp.main()