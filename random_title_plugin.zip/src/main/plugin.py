import handler.main as npp
import handler.log as log
import handler.config as config
import random

js = """
{
    "Enabled": true,
    "insert_text": ["Random Text 1","Random Text 2", "Random Text 3"]
}
"""
config.create("random_title_plugin",js)

if config.get_config("Enabled"):
    text = config.get_config("insert_text")
    ran = random.choice(text)
    npp.insert(ran)
else:
    log.error("Plugin has been disabled")
npp.set_custom_gui("Config",lambda: config.launch_config())





npp.main()