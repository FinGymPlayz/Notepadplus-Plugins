import handler.main as npp
import handler.log as log
import handler.config as config
from tkinter import *
from datetime import timedelta


def launch_window():
    w = Tk()
    launchtime = npp.FetchData().launchtime()
    def lt():
        launchtime = int(npp.FetchData().launchtime())
        td = timedelta(seconds=launchtime)
        tds = str(td).split(":")
        hours = tds[0]
        mins = tds[1]
        seconds = tds[2]
        lab.config(text=f"{hours}h : {mins}m : {seconds}s")
        lab.update()
        w.after(1000,lt)
    
    launchtime = int(npp.FetchData().launchtime())
    td = timedelta(seconds=launchtime)
    tds = str(td).split(":")
    hours = tds[0]
    mins = tds[1]
    seconds = tds[2]
    w.title("LaunchTime")
    w.config(bg="black")
    w.geometry("1000x150")
    lab = Label(w,text=f"{hours}h : {mins}m : {seconds}s",font="OpenSymbol 100 bold",fg="lime",bg="black")
    lab.place(relx=0.5, rely=0.5, anchor=CENTER)
    w.after(1000,lt)

    w.mainloop()

npp.set_custom_gui("Launchtime",launch_window)




npp.main()