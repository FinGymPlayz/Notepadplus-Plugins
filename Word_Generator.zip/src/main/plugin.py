import handler.main as npp
import handler.log as log
import handler.config as config
import requests
from tkinter import *

def random_word():
  def dest():
    lab.destroy() 
  word = requests.get("https://random-word-api.herokuapp.com/word").text
  list_word = eval(word)
  lab = Label(text="Word: "+list_word[0],bg=npp.bgc,fg=npp.fgc)
  lab.pack()
  lab.after(5000,dest)
npp.add_menu_item("Choose Random Word",random_word)



npp.main()
