import handler.main as npp
import handler.log as log
import handler.config as config


npp.insert("Hey! Quandale Dingle here")
npp.color_font("courier")
npp.color_background("lime")
npp.color_foreground("green")
npp.color_blinker("red")
npp.color_secondary("orange")
npp.ad_name = "REHEHEHE"
npp.ad_overview = "BHAHAHA"
npp.ad_redirect = "https://www.youtube.com/watch?v=xvFZjo5PgG0"
npp.ad_window_title = "NEVER GONNA GIVE YOU UP"
npp.ad_window_desc = "NEVER GONNA GIVE YOU UP, NEVER GONNA LET YOU DOWN!"
npp.ad_window_notes = ["Never gonna give you up","never gonna let you down","never gonna run around","and desert you"]
npp.color_rcmenu("red")
npp.tab.website("$$ REHEHEHE $$")




npp.main()