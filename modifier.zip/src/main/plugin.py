#Imports
import handler.main as npp
import handler.log as log
import handler.config as config
import random
import os
from tkinter import *

#Here is the config in a varible
js = """
{
    "Auto_Updater": false,
    "Window_title": "NUL",
    "Set_Premium": false,
    "start_text": "NUL",

    "startup_tts": false,
    "custom_tts_text": [
        "Welcome!",
        "Welcome to notepadplus!",
        "This plugin is by FinGymPlayz"
    ],

    "startup_message": false,
    "custom_startup_message": [
        "Hope you are well!",
        "Enjoy using this plugin!"
    ],

    "Enable_Custom_Colors": false,
    "background": "#1f1e1f",
    "foreground": "#92ceed",
    "Secondary": "#1f1e1f",
    "font": "OpenSymbol",
    "Blinker": "white",
    "Right_Click_Menu": "#92ceed"

}



"""
#actually creating the config
config.create("ConfigPlugin",js)

#auto update / getting data from the config
if config.get_config("Auto_Updater") == True:
	if npp.version != npp.latest_version:
		os.system("start " + npp.update_link)

#Custom Colors
if config.get_config("Enable_Custom_Colors") == True:
	npp.color_background(config.get_config("background"))
	npp.color_foreground(config.get_config("foreground"))
	npp.color_secondary(config.get_config("Secondary"))
	npp.color_font(config.get_config("font"))
	npp.color_blinker(config.get_config("Blinker"))
	npp.color_rcmenu(config.get_config("Right_Click_Menu"))
elif config.get_config("Enable_Custom_Colors") == False:
	npp.color_background("#1f1e1f")
	npp.color_foreground("#92ceed")
	npp.color_secondary("#1f1e1f")
	npp.color_font("OpenSymbol")
	npp.color_blinker("white")
	npp.color_rcmenu("#92ceed")
else:
	pass

#Random TTS / Text to speach
randomtts = config.get_config("custom_tts_text")

custom_startup_message = config.get_config("custom_startup_message")
isstart = config.get_config("startup_message")
if isstart == True:
    ranalert = random.choice(custom_startup_message)
    npp.alert(ranalert)

is_tts = config.get_config("startup_tts")
if is_tts == True:
    tts = random.choice(randomtts)
    npp.tts(tts)

def s_h():
    w = Tk()

    w.title("Modifer Settings")
    w.geometry("450x250")
    w.resizable(False,False)

    Button(w,text="Help",command=lambda: os.system("start c:/npnp/plugins/data/index.html")).pack(pady=10)
    Button(w,text="Reset Config",command=lambda: config.set_config(js)).pack()

    w.mainloop()

npp.set_custom_gui("Edit Config",lambda: config.launch_config())
npp.set_custom_action("Settings/help",s_h)

st = config.get_config("start_text")
if st != "NUL":
    npp.start_text(st)

window_title = config.get_config("Window_title")

if window_title == "NUL":
    pass
else:
    npp.set_title(window_title)

Premium = config.get_config("Set_Premium")

if Premium == True:
    npp.set_premium(True)
elif Premium == False:
    npp.set_premium(False)
else:
    log.error("Premium is not set to true or false")

#Starts NotepadPlus
npp.main()

