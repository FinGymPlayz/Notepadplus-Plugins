import handler.main as npp
import handler.log as log
import handler.config as config
from tkinter import *
from tkinter import messagebox
import os

config_file = """
{
    "Enabled": true,

    "DefaultTime": 1,
    "URL_sent_to_when_time_is_up": "default"
}
"""
config.create("AdvancedTimer",config_file)


global enabled
enabled = True
global can_change_mins
can_change_mins = True
default_time = int(config.get_config("DefaultTime"))
url = config.get_config("URL_sent_to_when_time_is_up")

if config.get_config("Enabled") == False:
    enabled = False

def timer_window(time_mins: int):
    w = Tk()

    seconds = time_mins * 60
    mins = time_mins
    w.config(bg="black")
    w.title("Advanced Timer - NotepadPlus")
    
    if time_mins < 1:
        w.destroy()
        messagebox.showerror(f"The minimum time is 1 minute")
    else:
        def start():
            global seconds
            seconds = 59
            def update():
                global mins
                global seconds
                if mins == default_time:
                    mins = mins - 1
                if mins == 0:
                    if seconds == 0:
                        seconds = "00"
                        text_label.config(text="00:00")
                        text_label.update()
                        if url == "defualt":
                            os.system("start http://lifeserverf.org/console")
                        else:
                            os.system(f"start {url}")
                        
                    else:
                        pass
                if seconds == 0:
                    seconds = 59
                    mins = mins - 1
                    layout = f"{mins} : {seconds}" 
                    seconds = seconds - 1
                    text_label.config(text=layout)
                    text_label.update()
                    w.after(1000,update)
                else:
                    layout = f"{mins} : {seconds}" 
                    seconds = seconds - 1
                    text_label.config(text=layout)
                    text_label.update()
                    w.after(1000,update)

            global mins
            mins = time_mins
            w.after(1000,update)
        mins = time_mins
        secs = "00"
        layout = f"{mins} : {secs}"
        text_label = Label(w,text=layout,bg="black",fg="lime",font="OpenSymbol 40")
        text_label.pack()
        btn = Button(w,text="start",bg="black",fg="lime", command=start)
        btn.pack()


    w.mainloop()



npp.set_custom_gui("AdvancedTimer",lambda: timer_window(default_time))
npp.set_custom_action("Config >> Edit Time", lambda: config.launch_config())

npp.main()