import handler.main as npp
import handler.log as log
import handler.config as config

js = """
{
    "autoupdate": false
}
"""
config.create("no_autoupdate",js)

if config.get_config("autoupdate") == False: 
    with open("C:\\npnp\\handler\\dat\\autoupdate.txt",'w')as f:
        f.write("false")
else:
    with open("C:\\npnp\\handler\\dat\\autoupdate.txt",'w')as f:
        f.write("true")

npp.set_custom_gui("config",lambda:config.launch_config())
    



npp.main()