import handler.main as npp
import handler.log as log
import handler.config as config


npp.check_version(4.12)

npp.color.text.colon("#FF00C9")




npp.main()