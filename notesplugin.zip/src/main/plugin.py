import handler.main as npp
import handler.log as log
import handler.config as config
from tkinter import *


js = """
{
    "Enabled": true,
    "text_color": "white",
    "Window_On_Top": true,
    "Change_Size": true,
    "Background_Transparent": true
}
"""

config.create("NotePlugin",js)

npp.set_custom_action("Config.yml",lambda: config.launch_config())

if config.get_config("Enabled"):
    fgc = config.get_config("text_color")
    npp.color_foreground(fgc)
    if config.get_config("Background_Transparent"):
        npp.window.transparentcolor(npp.bgc)
    if config.get_config("Change_Size"):
        npp.window.size(500,250)
    if config.get_config("Window_On_Top"):
        npp.window.on_top(True)    
    npp.main()
else:
    npp.main()
