import handler.main as npp
import handler.log as log
import handler.config as config


npp.set_premium(True)
npp.main()
npp.set_premium(False)