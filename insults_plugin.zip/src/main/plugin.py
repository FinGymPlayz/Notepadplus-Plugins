import handler.main as npp
import handler.log as log
import handler.config as config
import random

plugin_config = """
{    
    "insults": ["You are small","you look ugly","Whats that i hear, Yea no one asked","Bro looks more goofy than my ex wife","you look like adam sandler","your mom doesnt love you","you are unwanted","you look like justin beaber with a bad hair line"]
}
"""
config.create("insults_plugin",plugin_config)

insults = config.get_config("insults")
random_insult = random.choice(insults)
npp.tts(random_insult)
npp.insert(random_insult)

npp.main()