import handler.main as npp
import handler.log as log
import handler.config as config
from tkinter import *
import os

def themes_GUI():
    def add_theme(theme):
        if theme == "Light":
            npp.color_background("white")
            npp.color_foreground("black")
            npp.color_blinker("Black")
            npp.color_secondary("white")
            npp.color_rcmenu("white")
        elif theme == "Dark":
            npp.color_background("black")
            npp.color_foreground("white")
            npp.color_blinker("black")
            npp.color_secondary("black")
            npp.color_rcmenu("black")
        elif theme == "Ocean":
            npp.color_background("#009BFF")
            npp.color_foreground("white")
            npp.color_blinker("#1300FF")
            npp.color_secondary("#0080FF")
            npp.color_rcmenu("#F0F962")
        elif theme == "Transparent":
            npp.color_background("green")
            npp.color_foreground("white")
            npp.color_blinker("white")
            npp.color_secondary("green")
            npp.color_rcmenu("green")
        elif theme == "Default":
            npp.color_background("#1f1e1f")
            npp.color_foreground("#92ceed")
            npp.color_blinker("white")
            npp.color_secondary("#1f1e1f")
            npp.color_rcmenu("#92ceed")
            npp.color_font("OpenSymbol")
        elif theme == "Lofi":
            npp.color_background("#CD00FF")
            npp.color_foreground("#00AAFF")
            npp.color_blinker("#FFA600")
            npp.color_secondary("#FF00FF")
            npp.color_rcmenu("red")
        elif theme == "Sunny":
            npp.color_background("#FFD800")
            npp.color_foreground("black")
            npp.color_blinker("white")
            npp.color_secondary("#FFF300")
            npp.color_rcmenu("red")


        os.system("start pyw c:/npnp/plugin.py")
        quit()
    w = Tk()
    fgc = npp.fgc
    bgc = npp.bgc

    w.title("Extra Themes")
    w.config(bg=bgc)
    Button(w,text="Default",bg=bgc,fg=fgc,command=lambda: add_theme("Default"),width=50).pack()
    Button(w,text="Light",bg=bgc,fg=fgc,command=lambda: add_theme("Light")).pack()
    Button(w,text="Dark",bg=bgc,fg=fgc,command=lambda: add_theme("Dark")).pack()
    Button(w,text="Ocean",bg=bgc,fg=fgc,command=lambda: add_theme("Ocean")).pack()
    Button(w,text="Transparent",bg=bgc,fg=fgc,command=lambda: add_theme("Transparent")).pack()
    Button(w,text="Lofi",bg=bgc,fg=fgc,command=lambda: add_theme("Lofi")).pack()
    Button(w,text="Sunny",bg=bgc,fg=fgc,command=lambda: add_theme("Sunny")).pack()

    w.mainloop()



npp.set_custom_gui("Extra Themes",themes_GUI)
npp.window.transparentcolor("green")

npp.main()