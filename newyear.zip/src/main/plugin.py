import handler.main as npp
import handler.log as log
import handler.config as config








npp.main()