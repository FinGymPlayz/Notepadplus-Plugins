import handler.main as npp
import handler.log as log
import handler.config as config
from tkinter import *
import os

def run():
    bgc = npp.bgc
    fgc = npp.fgc
    data_file = []
    path_list = os.listdir("c:/npnp/handler/dat/")
    for file in path_list:
        if file.endswith(".txt"):
            data_file.append(file)
    data_file.remove("agreement.txt")
    w = Tk()
    def edit(file):
        contents = ent.get(1.0,END)
        with open(f"c:/npnp/handler/dat/{file}",'w')as f:
            f.write(contents)
    ent = Text(w,font="OpenSymbol 16 bold",bg="black",fg=fgc,height=10,wrap="word")
    ent.insert(END,"Type Text Here")
    ent.pack()
    w.config(bg=bgc)
    w.title("DataEdit - Notepadplus Plugin")
    for i in data_file:
        but = Button(w,text=f"Edit {i}",command=lambda name=i: edit(name),bg="black",fg="white",font="OpenSymbol 10 bold")
        but.pack()
    w.mainloop()

npp.set_custom_gui("DataEdit",run)



npp.main()