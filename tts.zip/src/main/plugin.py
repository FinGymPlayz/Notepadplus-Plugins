import handler.main as npp
import handler.log as log
import handler.config as config

js = """
{
    "enabled": true,
    "tts": "Change the text to speach message in the config"
}
"""

config.create("tts",js)
enabled = config.get_config("enabled")
if enabled:
    tts_message = config.get_config("tts")
    npp.tts(tts_message)

npp.set_custom_gui("Edit TTS config",lambda: config.launch_config())


npp.main()