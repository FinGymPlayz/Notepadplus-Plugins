import handler.main as npp
import handler.log as log
import handler.config as config
import os

if npp.is_online:
    os.system("start C:\\NPNP_Updater\\Updater.py")
else:
    npp.alert("You are offline, Please connect to an internet connection")
    npp.main()